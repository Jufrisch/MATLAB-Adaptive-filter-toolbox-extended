% Copyright 2018, Samuel Lichtenheld, All rights reserved.
%No noise
clc;
clear;

fs = 10000; % sampling frequency
T = .1;% total recording time
L = T .* fs; % signal length
freq = 1000;
tt = (0:L-1)/fs; % time vector
out = sin(2*pi*(freq*2) .* tt); out = out(:); % reference sinusoid
in = sin(2*pi*freq .* tt); in = in(:); % sinusoiud 
d = out(11:end); % shift because model order 5
desired = d;
%% Generate input and desired signals.
clc;clear;close all;
fs = 10000; % sampling frequency
T = .1;% total recording time
L = T .* fs; % signal length
tt = (0:L-1)/fs; % time vector
freq = 1000;
freq2 = freq*2;
out = sin(2*pi*freq2 .* tt); out = out(:); % reference sinusoid
in = sin(2*pi*freq .* tt); in = in(:); % sinusoiud 
d = out(11:end); % shift because model order 5
% Generate random variable obtained from gaussian mixture:
%   p(u) = 0.9G(0,0 . 1) + 0.1G(4,0 . 1)

pd1 = makedist('Normal','mu',0,'sigma',0.1);
pd2 = makedist('Normal','mu',4,'sigma',0.1);

size = length(d);
p=0.9+zeros(1,size);

r = binornd(1,p);
noiseP9 = random(pd1,1,L);
noiseP1 = random(pd2,1,L);

noise = zeros(size,1);
for ii = 1:length(r)
    if r(ii) == 1
        noise(ii) = noiseP1(ii);
    else
        noise(ii) = noiseP9(ii);
    end
end
desired = d;
d = d + noise;
       
        
     

%%
close all;
X = readDataStream(in,10);

% fprintf('training LMS...')
%lms = lms();
% lms.train(.001,X,d,1);
% lms.plotVal(1)
% lms.plotW(1)
% 
% fprintf('training RLS...')
% rls = rls();
% rls.train(.99,.001,X,d,1);
% 
% fprintf('training LMEE...')
% lmee = lms_mee();
% lmee.train(10,5,.1,X,d,1);
% 
tic
fprintf('training KLMS...')
klms = klms();
klms.train(1,1,X,d,10);
mse_error = klms.e_hist();
klms.plotVal(1)
[a,b] = ksdensity(mse_error);


toc
% fprintf('training KMCC...')
% kmcc = kmcc();
% kmcc.train(1,.5,.1,X,d,10);
tic
fprintf('training KMEE QIP...')
kmeeq = kmee_qip();
kmeeq.train(100,1,1,1,X,d,10);
kmeeq.plotPred(1);
hold on
klms.y_hist(900:950);
plot(desired(900:950));
plot(d(900:950));
hold off
legend('MEE Predicted', 'MSE Predicted','Desired', 'Desired+Noise')
kmeeq.plotNet(3)
kmeeq.plotVal(4)
toc

figure(5);
mee_error = kmeeq.e_hist();
[f,xi] = ksdensity(mee_error);
plot(xi,f);
hold on
%kmeeq.test(X,d)
mee_output = kmeeq.y_hist();
[f2,xi2] = ksdensity(mee_output);
%plot(xi2,f2);
plot(b,a)
hold off
legend('MEE','MSE')
title("PDF's of Filter Output and Error")

figure(6)
plot(kmeeq.e_hist)
title('Error History of MEE')

figure(7)
plot(klms.e_hist)
title('Error History of MSE')


kmeeq.plotPdf(8);
% fprintf('training KMEE Shannon...')
% kmees = kmee_shannon();
% kmees.train(50,1,.5,.5,X,d,10);
% 
% fprintf('training QKLMS...')
% q = qklms();
% q.train(1,.5,.1,X,d,10);
% q.plotNet(1)
% 
% fprintf('training QKMCC...')
% qkmcc = qkmcc();
% qkmcc.train(3,2,.5,.1,X,d,10);
% 
% fprintf('training QKMEE...')
% qkmee = qkmee();
% qkmee.train(2,50,1,.5,.5,X,d,10);
% 
% kmees.plotVal(1)

% q.train(4,.1,.04,trainIN,trainOUT,10);
%Final Learning NMSE:0.15148